[![Kodi Version](https://img.shields.io/badge/kodi-19%20|%2020%2B-blue)](https://kodi.tv/)
[![GitHub release](https://img.shields.io/github/release/rickeylohia/plugin.video.stalkervod.svg)](https://github.com/rickeylohia/plugin.video.stalkervod/releases)
[![codecov](https://codecov.io/github/rickeylohia/plugin.video.stalkervod/branch/main/graph/badge.svg?token=LFROXLYR12)](https://app.codecov.io/github/rickeylohia/plugin.video.stalkervod/tree/main)
[![License: GPLv3](https://img.shields.io/badge/License-GPLv3-yellow.svg)](https://opensource.org/licenses/GPL-3.0)
[![Contributors](https://img.shields.io/github/contributors/rickeylohia/plugin.video.stalkervod.svg)](https://github.com/rickeylohia/plugin.video.stalkervod/graphs/contributors)
[![Python application](https://github.com/rickeylohia/plugin.video.stalkervod/actions/workflows/python-app.yml/badge.svg?branch=main)](https://github.com/rickeylohia/plugin.video.stalkervod/actions/workflows/python-app.yml?query=branch%3Amain+)

# Stalker VOD Kodi add-on
**plugin.video.stalkervod** is a [Kodi](https://kodi.tv/) add-on for Stalker platform IPTV Client. You can watch Video On-Demand as well as TV Channels. 