# -*- coding: utf-8 -*-
"""Apply shipped server addresses/credentials to the user's saved settings."""
import json
import os
import xbmc
import xbmcaddon
import xbmcvfs

# Id taken from the install folder (addons/<id>/resources/lib), so it can never
# drift from the real add-on id.
ADDON_ID = os.path.basename(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
) or "plugin.video.xsfamily"


def sync_managed_connection_settings():
    """Apply the server addresses/credentials shipped in resources/settings.xml
    to the user's saved settings. Kodi only uses the shipped default= when no
    value has been saved, so after an update the old saved values would stay.
    Values the user edited by hand in Kodi are respected: only values still
    equal to what was applied last time (or empty) are updated. Empty shipped
    values never overwrite anything."""
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        import xml.etree.ElementTree as ET

        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        src = os.path.join(
            xbmcvfs.translatePath(addon.getAddonInfo("path")),
            "resources",
            "settings.xml",
        )
        suffixes = (
            "_xtream_url",
            "_xtream_username",
            "_xtream_password",
            "_m3u",
            "_epg_m3u",
            "_epg_xtream",
        )
        managed = {}
        for el in ET.parse(src).getroot().iter("setting"):
            sid = el.get("id") or ""
            val = el.get("default")
            if (
                sid.startswith("profile_")
                and sid.endswith(suffixes)
                and val
            ):
                managed[sid] = val
        marker = os.path.join(profile, "managed_settings.json")
        previous = None
        if os.path.exists(marker):
            try:
                with open(marker, "r", encoding="utf-8") as f:
                    previous = json.load(f)
            except Exception:
                previous = None
        if previous == managed:
            return
        changed = 0
        kept = 0
        for sid, val in managed.items():
            cur = addon.getSetting(sid)
            if cur == val:
                continue
            # Update only if the user never edited it: empty, or still equal to
            # the value we applied last time. First run (no snapshot): migrate.
            if previous is None or not cur or cur == previous.get(sid):
                addon.setSetting(sid, val)
                changed += 1
            else:
                kept += 1
        if not os.path.exists(profile):
            os.makedirs(profile)
        with open(marker, "w", encoding="utf-8") as f:
            json.dump(managed, f)
        xbmc.log(
            f"[XStream Player] Shipped connection settings: {changed} applied, {kept} kept (user-edited)",
            xbmc.LOGINFO,
        )
    except RuntimeError as e:
        # "Unknown addon id": Kodi is replacing the add-on files (update in
        # progress). Harmless: the sync runs again on the next start.
        xbmc.log(
            f"[XStream Player] Connection settings sync postponed (add-on updating): {e}",
            xbmc.LOGINFO,
        )
    except Exception as e:
        xbmc.log(f"[XStream Player] Connection settings sync failed: {e}", xbmc.LOGERROR)


def sync_default_profile_names():
    """Rename auto-generated profile names ("Family TV 1", "Profile 1", "Perfil 1",
    empty...) saved in the user's settings to "Family N". Names the user
    customised (anything else) are left untouched."""
    try:
        import re

        addon = xbmcaddon.Addon(ADDON_ID)
        generic = re.compile(r"^(family|family\s*tv|profile|perfil)?\s*\d+$", re.I)
        tags = re.compile(r"\[/?COLOR[^\]]*\]", re.I)
        changed = 0
        for n in range(1, 11):
            sid = f"profile_{n}_name"
            cur = (addon.getSetting(sid) or "").strip()
            plain = tags.sub("", cur).strip()
            target = f"Family {n}"
            if cur == target:
                continue
            if not plain or generic.match(plain):
                addon.setSetting(sid, target)
                changed += 1
        if changed:
            xbmc.log(
                f"[XStream Player] Renamed {changed} default profile names to Family N",
                xbmc.LOGINFO,
            )
    except Exception as e:
        xbmc.log(f"[XStream Player] Profile name sync failed: {e}", xbmc.LOGWARNING)
