# -*- coding: utf-8 -*-
"""Runs at Kodi startup: applies shipped connection settings after an update."""
from sync_settings import sync_managed_connection_settings

sync_managed_connection_settings()
