# -*- coding: utf-8 -*-
"""Apply shipped server addresses/credentials to the user's saved settings."""
import json
import os
import xbmc
import xbmcaddon
import xbmcvfs


def sync_managed_connection_settings():
    """Apply the server addresses/credentials shipped in resources/settings.xml
    to the user's saved settings. Kodi only uses the shipped default= when no
    value has been saved, so after an update the old saved values would stay.
    Values the user edited by hand in Kodi are respected: only values still
    equal to what was applied last time (or empty) are updated. Empty shipped
    values never overwrite anything."""
    try:
        addon = xbmcaddon.Addon("plugin.video.xsfamily")
        import xml.etree.ElementTree as ET

        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        src = os.path.join(
            xbmcvfs.translatePath(addon.getAddonInfo("path")),
            "resources",
            "settings.xml",
        )
        suffixes = (
            "_xtream_url",
            "_xtream_username",
            "_xtream_password",
            "_m3u",
            "_epg_m3u",
            "_epg_xtream",
        )
        managed = {}
        for el in ET.parse(src).getroot().iter("setting"):
            sid = el.get("id") or ""
            val = el.get("default")
            if (
                sid.startswith("profile_")
                and sid.endswith(suffixes)
                and val
            ):
                managed[sid] = val
        marker = os.path.join(profile, "managed_settings.json")
        previous = None
        if os.path.exists(marker):
            try:
                with open(marker, "r", encoding="utf-8") as f:
                    previous = json.load(f)
            except Exception:
                previous = None
        if previous == managed:
            return
        changed = 0
        kept = 0
        for sid, val in managed.items():
            cur = addon.getSetting(sid)
            if cur == val:
                continue
            # Update only if the user never edited it: empty, or still equal to
            # the value we applied last time. First run (no snapshot): migrate.
            if previous is None or not cur or cur == previous.get(sid):
                addon.setSetting(sid, val)
                changed += 1
            else:
                kept += 1
        if not os.path.exists(profile):
            os.makedirs(profile)
        with open(marker, "w", encoding="utf-8") as f:
            json.dump(managed, f)
        xbmc.log(
            f"[XStream Player] Shipped connection settings: {changed} applied, {kept} kept (user-edited)",
            xbmc.LOGINFO,
        )
    except Exception as e:
        xbmc.log(f"[XStream Player] Connection settings sync failed: {e}", xbmc.LOGERROR)
