﻿1.1.2

Búsqueda: no se guarda caché vacía y se da más tiempo a la descarga del catálogo.

1.1.1

Búsqueda corregida (sin peticiones por resultado, nombres nulos); nombres de perfil en amarillo.

To disable changelog go to Tools/Settings/Update






