To disable changelog go to Tools/Settings/Update

1.0.6

nuevos canales


