1.2.6

TV en directo: si un canal pierde la señal, el reproductor se queda en el canal y reintenta la conexión automáticamente hasta que vuelve la señal, en lugar de cerrarse. Pulsar Stop lo cancela. Se puede desactivar en Ajustes > General > Live TV.

1.2.3

La sincronización de direcciones ahora también se ejecuta al iniciar Kodi (servicio), sin abrir el plugin.

1.2.2

Las direcciones y credenciales de resources/settings.xml ahora se aplican al actualizar el plugin, respetando los cambios hechos a mano en Kodi.

1.1.3

Búsqueda: las series ahora se abren correctamente (id de serie corregido).

1.1.2

Búsqueda: no se guarda caché vacía y se da más tiempo a la descarga del catálogo.

1.1.1

Búsqueda corregida (sin peticiones por resultado, nombres nulos); nombres de perfil en amarillo.

To disable changelog go to Tools/Settings/Update

1.0.6

nuevos canales


