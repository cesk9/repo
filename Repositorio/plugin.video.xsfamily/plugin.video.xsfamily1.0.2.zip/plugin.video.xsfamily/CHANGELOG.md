To disable changelog go to Tools/Settings/Update

Version 1.0.2

- When unloading PVR it deletes settings from PVR client
- Bug Fixes

