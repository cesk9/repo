1.1.3

Búsqueda: las series ahora se abren correctamente (id de serie corregido).

1.1.2

Búsqueda: no se guarda caché vacía y se da más tiempo a la descarga del catálogo.

1.1.1

Búsqueda corregida (sin peticiones por resultado, nombres nulos); nombres de perfil en amarillo.

To disable changelog go to Tools/Settings/Update

1.0.6

nuevos canales


