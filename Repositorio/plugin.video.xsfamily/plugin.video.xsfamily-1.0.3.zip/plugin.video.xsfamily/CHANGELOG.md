To disable changelog go to Tools/Settings/Update

Version 1.0.3

- Fixed plugin ID inconsistency (plugin.video.xsfamily)
- Removed hardcoded credentials from settings.xml
- Bug fixes

Version 1.0.2

- When unloading PVR it deletes settings from PVR client
- Bug Fixes

