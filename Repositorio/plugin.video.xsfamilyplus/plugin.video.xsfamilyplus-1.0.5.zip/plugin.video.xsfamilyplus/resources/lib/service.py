# -*- coding: utf-8 -*-
"""Runs at Kodi startup.

1. Applies shipped connection settings after an update.
2. Keeps playback going: when the signal of a live channel is lost (stream
   ends or errors out) the channel is re-opened over and over until the
   signal comes back, instead of leaving the player. Movies and series
   (online streams) are re-opened at the point where they dropped.
   Pressing Stop yourself cancels the reconnection.
"""
import time

import xbmc
import xbmcaddon
import xbmcgui

from sync_settings import sync_managed_connection_settings

ADDON_ID = "plugin.video.xsfamily"
LOG = "[XStream Player] "

RETRY_DELAY = 3.0  # seconds between reconnection attempts
VOD_END_MARGIN = 30.0  # "ended" this close to the end of a movie = real end
VOD_MAX_RETRY = 600.0  # give up on a movie/series after this many seconds
STABLE_AFTER = 8.0  # playing this long after a retry => signal is back
IGNORE_STOP_WINDOW = 2.0  # a Stop this soon after our own play() is a failed attempt

_MSG = {
    "es": (
        "Señal perdida. Reconectando…",
        "Señal recuperada",
        "No se pudo reconectar",
    ),
    "en": ("Signal lost. Reconnecting…", "Signal restored", "Could not reconnect"),
}


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(LOG + msg, level)


def _setting_bool(addon, key, default=True):
    val = addon.getSetting(key)
    if val == "":
        return default
    return val.lower() == "true"


def _msg(addon, idx):
    lang = (addon.getSetting("interface_language") or "").lower()
    pair = _MSG["es"] if lang.startswith("esp") else _MSG["en"]
    return pair[idx]


class LivePlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.addon = xbmcaddon.Addon(ADDON_ID)
        self.current_file = ""
        self.current_item = None
        self.is_live = False
        self.is_vod = False
        self.last_pos = 0.0
        self.last_total = 0.0
        self.resume_pos = 0.0
        self.lost_at = 0.0
        self.started_at = 0.0
        # Reconnection state
        self.retrying = False
        self.target_file = ""
        self.target_item = None
        self.last_attempt = 0.0
        self.attempt_started = False  # AV started since last attempt
        self.attempts = 0
        self.notified = False

    # --- helpers -----------------------------------------------------------
    def _enabled(self, vod=False):
        try:
            self.addon = xbmcaddon.Addon(ADDON_ID)  # refresh settings
            key = "vod_auto_reconnect" if vod else "live_auto_reconnect"
            return _setting_bool(self.addon, key, True)
        except Exception:
            return True

    def _track(self):
        """While a movie/series from an online stream plays, remember where we are."""
        if not self.isPlaying():
            return
        try:
            if self.is_live or not self.current_file:
                return
            if not self.current_file.lower().startswith(("http://", "https://")):
                return  # local files are never "reconnected"
            total = self.getTotalTime()
            if total > 0:
                self.is_vod = True
                self.last_total = total
                self.last_pos = self.getTime()
        except Exception:
            pass

    def _detect_live(self):
        """Live = a PVR TV/radio channel, or a live stream opened by this addon
        (it flags the URL in a window property). Never VOD, so a movie that
        ends normally is never "reconnected"."""
        try:
            if xbmc.getCondVisibility("Pvr.IsPlayingTv") or xbmc.getCondVisibility(
                "Pvr.IsPlayingRadio"
            ):
                return True
            flagged = xbmcgui.Window(10000).getProperty("xsfamily.live_url")
            if flagged and flagged == self.current_file:
                return True
        except Exception:
            pass
        return False

    def _stop_retrying(self, reason=""):
        if self.retrying:
            _log(f"Live reconnect stopped ({reason})")
        self.retrying = False
        self.target_file = ""
        self.target_item = None
        self.attempts = 0
        self.notified = False

    # --- Kodi callbacks ----------------------------------------------------
    def onAVStarted(self):
        try:
            self.current_file = self.getPlayingFile()
        except Exception:
            self.current_file = ""
        try:
            self.current_item = self.getPlayingItem()
        except Exception:
            self.current_item = None
        self.started_at = time.time()

        if self.retrying:
            if self.current_file == self.target_file:
                self.attempt_started = True
                return
            # something else is playing now (user switched channel) -> stand down
            self._stop_retrying("another item started")

        self.is_live = self._detect_live()
        self.is_vod = False
        self.last_pos = 0.0
        self.last_total = 0.0

    def onPlayBackEnded(self):
        # Stream ended on its own: for live TV that means signal loss.
        self._on_lost("ended")

    def onPlayBackError(self):
        self._on_lost("error")

    def onPlayBackStopped(self):
        if self.retrying:
            # Our own failed play() can emit Stop right away; a later Stop is the user.
            if time.time() - self.last_attempt < IGNORE_STOP_WINDOW:
                return
            self._stop_retrying("stopped by user")
            return
        self._clear_current()

    def _clear_current(self):
        self.is_live = False
        self.is_vod = False
        self.current_file = ""
        self.current_item = None

    def _on_lost(self, kind):
        if self.retrying:
            # a retry attempt failed; the loop will try again
            self.attempt_started = False
            return
        if not self.current_file:
            self._clear_current()
            return
        if self.is_live:
            if not self._enabled():
                self._clear_current()
                return
        elif self.is_vod and self._enabled(vod=True):
            remaining = self.last_total - self.last_pos
            if kind == "ended" and remaining <= VOD_END_MARGIN:
                self._clear_current()  # the movie/episode really finished
                return
            self.resume_pos = max(0.0, self.last_pos - 3.0)
        else:
            self._clear_current()
            return
        _log(f"Signal lost ({kind}): {self.current_file} at {self.last_pos:.0f}s")
        self.lost_at = time.time()
        self.retrying = True
        self.target_file = self.current_file
        self.target_item = self.current_item
        # first retry after RETRY_DELAY, so a channel zap in progress isn't interrupted
        self.last_attempt = time.time()
        self.attempt_started = False
        self.attempts = 0
        self.notified = False

    # --- reconnection loop (called from the service loop) ------------------
    def tick(self):
        if not self.retrying:
            self._track()
            return
        now = time.time()
        if self.isPlaying():
            # A new, different item the user chose -> stop interfering
            try:
                if self.getPlayingFile() != self.target_file:
                    self._stop_retrying("another item playing")
                    return
            except Exception:
                pass
            if self.attempt_started and now - self.started_at >= STABLE_AFTER:
                if self.notified:
                    xbmcgui.Dialog().notification(
                        "XStream Player",
                        _msg(self.addon, 1),
                        xbmcgui.NOTIFICATION_INFO,
                        2000,
                    )
                _log(f"Signal restored after {self.attempts} attempt(s)")
                self.is_live = not self.is_vod
                self.current_file = self.target_file
                self.retrying = False
                self.attempts = 0
                self.notified = False
            return
        if now - self.last_attempt < RETRY_DELAY:
            return
        if not self._enabled(vod=self.is_vod):
            self._stop_retrying("disabled")
            return
        if self.is_vod and now - self.lost_at > VOD_MAX_RETRY:
            xbmcgui.Dialog().notification(
                "XStream Player",
                _msg(self.addon, 2),
                xbmcgui.NOTIFICATION_ERROR,
                4000,
            )
            self._stop_retrying("gave up")
            self._clear_current()
            return
        if not self.notified:
            xbmcgui.Dialog().notification(
                "XStream Player",
                _msg(self.addon, 0),
                xbmcgui.NOTIFICATION_WARNING,
                3000,
            )
            self.notified = True
        self.attempts += 1
        self.last_attempt = now
        self.attempt_started = False
        _log(f"Reconnecting to live stream (attempt {self.attempts})")
        try:
            item = self.target_item
            if self.is_vod:
                if item is None:
                    item = xbmcgui.ListItem(path=self.target_file)
                # resume where the stream dropped
                item.setProperty("StartOffset", str(int(self.resume_pos)))
            if item is not None:
                self.play(self.target_file, item)
            else:
                self.play(self.target_file)
        except Exception as e:
            _log(f"Reconnect play() failed: {e}", xbmc.LOGWARNING)


def run():
    sync_managed_connection_settings()
    monitor = xbmc.Monitor()
    player = LivePlayer()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
        try:
            player.tick()
        except Exception as e:
            _log(f"Live reconnect loop error: {e}", xbmc.LOGERROR)


run()
